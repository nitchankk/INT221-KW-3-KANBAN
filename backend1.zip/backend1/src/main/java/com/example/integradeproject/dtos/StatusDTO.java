package com.example.integradeproject.dtos;

import lombok.Data;

@Data

public class StatusDTO {
    private Integer id;
    private String name;
    private String description;
}
